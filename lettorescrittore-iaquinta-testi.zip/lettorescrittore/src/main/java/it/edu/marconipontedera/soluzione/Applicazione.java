package it.edu.marconipontedera.soluzione;

import java.util.Scanner;

public class Applicazione {

    public static void main(String[] args) throws InterruptedException {

        int lettori;                                     													// Numero totale dei lettori
        int scrittori;                                   													// Numero totale degli scrittori
        
        long fineLezione;                                													// Tempo in millisecondi che indica quando termina la lezione
        
        Scanner scanner = new Scanner(System.in);        													

        System.out.print("Numero lettori: ");																// Numero Lettori
        lettori = scanner.nextInt();                     													
        
        System.out.print("Numero scrittori: ");																// Numero Lettori
        scrittori = scanner.nextInt();                   													

        System.out.print("Durata lezione (secondi): ");														// Durata Lezione
        int durata = scanner.nextInt();                 													

        scanner.nextLine();                             													

        int persone = lettori + scrittori;             														// Numero totale delle persone
        String[] nomi = new String[persone];            													// Array dei nomi delle persone
        
        System.out.print("Vuoi inserire i nomi delle persone? (s/n): ");
        String scelta = scanner.nextLine();            													

        if (scelta.equals("s")) {                       													// Inserimento manuale dei nomi

            for (int i = 0; i < persone; i++) {
                System.out.print("Inserisci il nome della persona " + (i + 1) + ": ");
                nomi[i] = scanner.nextLine();          													
            }

        } else {                                       														// Generazione automatica dei nomi

            for (int i = 0; i < persone; i++) {
                nomi[i] = "Persona " + (i + 1);       														 
            }
        }

        Lavagna lavagna = new Lavagna();               														// Creazione della lavagna condivisa
        Thread[] threadsLettori = new Thread[lettori];       												// Array dei thread lettori
        Thread[] threadsScrittori = new Thread[scrittori];     												// Array dei thread scrittori
        
        fineLezione = System.currentTimeMillis() + (durata * 1000);											// Impostazione del tempo di fine lezione

        System.out.print("\n");

        for (int i = 0; i < scrittori; i++) {																// Creazione dei thread scrittori
        	threadsScrittori[i] = new Thread(
                new Scrittore(nomi[i], lavagna, fineLezione)
            );
        	threadsScrittori[i].start();                    														 
        }

        for (int i = 0; i < lettori; i++) {																	// Creazione dei thread lettori usando i nomi a partire dalla posizione "scrittori + i" per non sovrascrivere quelli già assegnati agli scrittori
																
        	threadsLettori[i] = new Thread(
                new Lettore(nomi[scrittori + i], lavagna, fineLezione)
            );
        	threadsLettori[i].start();                    														 
        }

        while (System.currentTimeMillis() < fineLezione) {
        	Thread.sleep(100);
        }																									// Attesa del termine della lezione

        lavagna.finisciLezione();                        													// Blocco totale degli accessi alla lavagna

        for (int i = 0; i < scrittori; i++) {																// Attesa che tutti i thread scrittori terminino
        	threadsScrittori[i].join();
        }
        
        for (int i = 0; i < lettori; i++) {																	// Attesa che tutti i thread lettori terminino
        	threadsLettori[i].join();
        }

        System.out.println("\n>>> CAMPANELLA: fine lezione <<<");											// Messaggio finale
        
        scanner.close();                                													// Chiusura scanner
    }
}
