package it.edu.marconipontedera;
import java.util.Random;

public class Lavagna {

    private String valore = "Oggi interroghiamo";                   // Valore corrente scritto sulla lavagna
    private int persone;                                           	// Numero totale di persone nella stanza
    private int turnoCorrente;                                     	// Numero della persona che può scrivere in questo turno
    private boolean[] haLetto;                                     	// Array che indica chi ha già letto il valore corrente
    private int letti = 0;                                         	// Contatore di quante persone hanno letto la lavagna
    private Random random = new Random();                           // Generatore casuale per scegliere parole e turni
    private int indice;                                             // Indice della parola scelta casualmente
    
    public boolean lezioneFinita = false;                          	// Flag per indicare se la lezione è terminata
    public boolean ultimoGiro = false;                             	// Flag per garantire che tutti leggano l'ultima parola e quindi questo è l'ultimo giro

    private String[] parole = {
            "cane","gatto","pane","luna","sole","albero","carta","mare","vento","fuoco",
            "scuola","penna","libro","tavolo","sedia","porta","finestra","strada","auto","treno",
            "cuore","voce","mano","occhio","sale","dado","computer","mouse","tastiera","zaino",
            "colore","mela","pera","ulivo","montagna","fiume","neve","pioggia","oro","argento",
            "tempo","gioco","bici","telefono","chiave","notte","giorno","pizza","pasta","testo",
            "foglia","erba","fiore","campo","sole","lago","cielo","nuvola","città","paese",
            "stella","pianeta","razzo","tigre","leone","orso","vino","acqua","bottiglia","vetro",
            "gomma","righello","matita","lavagna","sabbia","roccia","isola","spiaggia","onda","valle",
            "robot","codice","rete","server","stanza","classe","porta","muro","letto","sogno"
        };                           	

    public Lavagna(int persone) {
        this.persone = persone;
        this.haLetto = new boolean[persone + 1];                  	// Creazione array
        
        resetLetture();                                           	// Inizializza tutti i valori di lettura a false
        
        this.turnoCorrente = random.nextInt(persone) + 1;        	// Sceglie il primo thread che inizierà a scrivere a scrivere
    }

    public synchronized void leggi(String nome, int numeroElenco) {

        if (!haLetto[numeroElenco]) {                             	// Se il thread non ha ancora letto la parola corrente, legge e dice cosa legge
            System.out.println(nome + " legge: " + valore);       	// Altrimenti il thread esce dal metodo leggi()
            
            haLetto[numeroElenco] = true;                         	// Segna che il thread ha letto
            letti++;                                               	// Incrementa contatore letti
            
            notifyAll();                                           	// Sveglia gli altri thread eventualmente in wait ma sopratutto sveglia il thread che deve scrivere
        }
    }

    public synchronized void scrivi(String nome) {

        while (letti < persone && !ultimoGiro) {                  	// Aspetta che tutti leggano prima di scrivere una nuova parola (tranne per l'ultimo giro)
            try { 
            	this.wait();                                      	// Il thread si sospende finché non viene notificato
            } catch (InterruptedException e) {
            	System.out.println(e);
            }
        }

        if (lezioneFinita) {                                      	// Se la lezione è terminata
        	ultimoGiro = true;                                     	// Attiva l’ultimo giro per far leggere tutti l’ultima parola
            notifyAll();                                           	// Sveglia tutti i thread
            return;                                                	// Esce dal metodo senza scrivere
        }

        System.out.println("\nIl professore chiama alla lavagna: " 
        + nome); 
        
        indice = random.nextInt(parole.length);                    	// Sceglie parola casuale
        valore = parole[indice];                                   	// Aggiorna il valore della lavagna

        System.out.println(nome + " scrive: " + valore + "\n");   	// Stampa chi scrive e cosa scrive

        resetLetture();                                           	// Tutti i thread possono rileggere la nuova parola

        turnoCorrente = random.nextInt(persone) + 1;             	// Sceglie casualmente il prossimo turno

        try { 
        	Thread.sleep(1000);                                    	// Breve pausa per rendere l'output più lento
        } catch (InterruptedException e)
        {
        	System.out.println(e);
        }

        notifyAll();                                               	// Sveglia tutti i thread in attesa
    }

    public void resetLetture() {                                  	// Resetta lo stato di lettura per tutti i thread
        for (int i = 1; i <= persone; i++) {
            haLetto[i] = false;
        }
        letti = 0;
    }

    public int getTurno() {                                        	// Restituisce il numero del thread che ha il turno
        return turnoCorrente;
    }
}
