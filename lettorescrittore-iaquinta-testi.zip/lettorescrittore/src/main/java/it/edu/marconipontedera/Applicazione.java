package it.edu.marconipontedera;
import java.util.Scanner;

public class Applicazione {

    public static void main(String[] args) throws InterruptedException {

        int persone;                                     													// Numero totale di persone nella stanza
        
        long fineLezione;                                													// Tempo in ms e indica dopo quanto termina la lezione, 
        																									// Tipo long e non di tipo int perché System.currentTimeMillis() restituisce il numero di millisecondi trascorsi dal 1 gennaio 1970. 
        																									// Questo numero è enorme (tipo 1.7 * 10¹²), quindi non può entrare in un int.
        Scanner scanner = new Scanner(System.in);        													

        System.out.println("Inserisci il numero di persone nella stanza: ");
        persone = scanner.nextInt();                     													
        scanner.nextLine();                              													

        String[] nomi = new String[persone];             													// Array dei nomi delle persone
        int[] numeroElenco = new int[persone];           													// Array del numero d'elenco delle persone per permettere di identificarle

        System.out.println("Vuoi inserire i nomi delle persone? (s/n): ");
        String scelta = scanner.nextLine();              													

        if (scelta.equals("s")) {                        													

            for (int i = 0; i < persone; i++) {          													// Ciclo per chiedere un nome a persona
                System.out.print("Inserisci il nome della persona " + (i+1) + ": ");
                nomi[i] = scanner.nextLine();            													
                numeroElenco[i] = i+1;                   													// L'assegnazione del numero dell'elenco procede insieme con l'assegnazione dei nomi
            }																								// Alla prima persona viene dato il numero 1, alla seconda il numero 2 e così via.

        } else {                                         													

            for (int i = 0; i < persone; i++) {          													// Ciclo che genera automaticamente i nomi
                nomi[i] = "Persona" + (i+1);            	 												
                numeroElenco[i] = i+1;                   													
            }																								
        }

        System.out.println("\n");

        Lavagna lavagna = new Lavagna(persone);                												// Crea la lavagna condivisa
        Thread[] threads = new Thread[persone];                												// Array dei thread delle persone

        fineLezione = System.currentTimeMillis() + 6000;       												// Fine della lezione: ora + 6 secondi

        for (int i = 0; i < persone; i++) {                    												// Ciclo per creare e avviare i thread
            threads[i] = new Thread(
                new Persona(nomi[i], lavagna, numeroElenco[i], fineLezione)
            );                                                 												// Ogni thread rappresenta una persona con nome ed numeroElenco diversi, lavagna e fineLezione hanno stessi valori per tutti
            threads[i].start();                               	 											// Avvio del thread
        }

        for (int i = 0; i < persone; i++) {                    												// Attesa che tutti i thread finiscano
            try {
                threads[i].join();                             												
            } catch (InterruptedException e) {
                System.out.println(e);
            }
        }

        System.out.println(">>> CAMPANELLA: fine lezione <<<"); 											// Messaggio finale
        
        scanner.close();                                        											
    }
}
