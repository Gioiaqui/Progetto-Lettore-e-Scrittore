package it.edu.marconipontedera.soluzione;

public class Scrittore implements Runnable {

    private String nome;                             														// Nome dello scrittore
    private Lavagna lavagna;                         														// Lavagna condivisa
    private long fineLezione;                        														// Tempo di fine lezione
    private boolean haScritto;
    
    public Scrittore(String nome, Lavagna lavagna, long fineLezione) {

        this.nome = nome;                            														
        this.lavagna = lavagna;                      														
        this.fineLezione = fineLezione;              														
    }

    public void scrivi() {

    	while (System.currentTimeMillis() < fineLezione) {													// Finché non suona la campanella

                haScritto = lavagna.inizioScrittura(nome);        											// Tentativo di scrittura
                while (!haScritto) {																		
                	return;           
                }																							// Se la lezione è finita esce

                try {
					Thread.sleep(800);
				} catch (InterruptedException e) {
					
					System.out.println(e);
				}                    																		// Tempo di scrittura
               
                lavagna.fineScrittura(nome);          														// Fine scrittura

                try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
				
					System.out.println(e);
				}                   																		// Pausa tra una scrittura e l'altra
            }

        } 

    public void run() {

        scrivi();                                   														
    }
}
