package it.edu.marconipontedera.soluzione;

public class Lavagna {

    private int lettori = 0;                             													// Numero dei lettori attivi
    private boolean scrittura = false;                  													// Indica se uno scrittore sta scrivendo
    private boolean lezioneFinita = false;             														// Indica se la lezione è terminata

    public synchronized boolean inizioScrittura(String nome) {

        while (!lezioneFinita && (scrittura || lettori > 0)) {												// Guardia: attende se qualcuno sta leggendo o scrivendo
            try { 
            	this.wait();
            }
            catch (InterruptedException e){
            	System.out.println(e);
            	
            }
        }

        if (lezioneFinita) { 
        	return false;   
        }																									// Se la lezione è finita non entra più nessuno

        scrittura = true;                             														// Inizio scrittura
        System.out.println(nome + " SCRIVE");          													
        
        return true;
    }

    public synchronized void fineScrittura(String nome) {

        System.out.println(nome + " HA FINITO DI SCRIVERE");												// Fine scrittura 
        scrittura = false;                         															// Libera la lavagna
        notifyAll();                              															// Risveglia tutti i thread in attesa
    }

    public synchronized boolean inizioLettura(String nome){

        while (!lezioneFinita && scrittura) {            													// Guardia: attende se qualcuno sta scrivendo
            try { 
            	this.wait();
            }
            catch (InterruptedException e){
            	System.out.println(e);
            	
            }
        }

        if (lezioneFinita) {
        	return false;                     																// Se la lezione è finita non entra più nessuno

        }
        
        lettori++;                                 															// Incrementa il numero dei lettori
        System.out.println(nome + " LEGGE");          													
        return true;
    }

    public synchronized void fineLettura(String nome) {

        System.out.println(nome + " HA FINITO DI LEGGERE");													// Fine lettura
        lettori--;                                															// Decrementa il numero dei lettori

        if (lettori == 0) {                         														// Se non ci sono più lettori
            System.out.println();                   														// Spazio tra una iterazione e l'altra
            notifyAll();                             														// Risveglia gli scrittori in attesa
        }
    }

    public synchronized void finisciLezione() {           													// Metodo chiamato alla campanella
        lezioneFinita = true;                      															// Imposta la fine della lezione
        notifyAll();                              															// Sblocca tutti i thread
    }
}
