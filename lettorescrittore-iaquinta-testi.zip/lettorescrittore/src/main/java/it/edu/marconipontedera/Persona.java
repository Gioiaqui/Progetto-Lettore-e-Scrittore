package it.edu.marconipontedera;

public class Persona implements Runnable {

    private String nome;                  													// Nome della persona
    private Lavagna lavagna;              													// Lavagna condivisa tra tutti i thread
    private long campanella;              													// Variabile che indica la fine lezione
    private int numeroElenco;             													// Numero identificativo della persona (ordine alfabetico)

    public Persona(String nome, Lavagna lavagna, int numeroElenco, long campanella) {     												 
        this.nome = nome;                 
        this.lavagna = lavagna;           
        this.numeroElenco = numeroElenco; 
        this.campanella = campanella;     
    }

    @Override
    public void run() {                 													// Metodo che viene eseguito quando parte il thread
        lezione();                       													
    }

    public void lezione() {             												

        while (true) {                   													// Ciclo infinito fino a fine lezione

            synchronized (lavagna) {      													// Blocca la lavagna per evitare conflitti tra thread

                if (System.currentTimeMillis() >= campanella) {                            	// Controlla se è finita la lezione, se è finita imposta la variabile lezioneFinita e ultimoGiro a true e notifica tutti i thread
                    lavagna.lezioneFinita = true;                                          
                    lavagna.ultimoGiro = true;                                            
                    lavagna.notifyAll();                                                   	// Risveglia tutti i thread in attesa
                }

                while (lavagna.getTurno() != numeroElenco && !lavagna.ultimoGiro) {        	// Aspetta il proprio turno o l'ultimo giro
                																			// Questo permette a tutti i thread di leggere l’ultima parola, anche se non è il loro turno, prima di uscire dal ciclo.
                    lavagna.leggi(nome, numeroElenco);                                     	// Se non è il suo turno, legge dalla lavagna per "seguire la lezione"
                    try { 
                    	lavagna.wait();                                                     // Thread in attesa perché ha già letto la lavagna e non è il suo turno, verrà svegliato se qualcuno nuovo scrive alla lavagna opure se è finita la lezione
                    } catch (InterruptedException e) {
                    	System.out.println(e);
                    }
                }

                lavagna.leggi(nome, numeroElenco);                                         	// Legge dalla lavagna anche colui che è alla lavagna

                if (lavagna.ultimoGiro) {                                                  	// Se è l’ultimo giro, esce dal ciclo e quindi non scrive, se la lezione è finita finisce comunque di scrivere
                    break;
                }

                lavagna.scrivi(nome);                                                       // Scrive sulla lavagna
            }
        }

        System.out.println(nome + " smette di seguire la lezione");                       	// Messaggio finale per la persona
    }
}
