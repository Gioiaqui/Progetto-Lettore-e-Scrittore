package it.edu.marconipontedera.soluzione;

public class Lettore implements Runnable {

    private String nome;                             														// Nome del lettore
    private Lavagna lavagna;                         														// Lavagna condivisa
    private long fineLezione;                        														// Tempo di fine lezione
    private boolean haLetto;
    
    public Lettore(String nome, Lavagna lavagna, long fineLezione) {

        this.nome = nome;                            														
        this.lavagna = lavagna;                      														
        this.fineLezione = fineLezione;              														
    }

    public void leggi() {

            while (System.currentTimeMillis() < fineLezione) {												// Finché non suona la campanella

                haLetto = lavagna.inizioLettura(nome);         												// Tentativo di lettura
                
                while (!haLetto) { 																			
                	return;     
                }																							// Se la lezione è finita esce

                try {
					Thread.sleep(500);
				} catch (InterruptedException e) {
					System.out.println(e);
				}                    																		// Tempo di lettura
                
                lavagna.fineLettura(nome);            														// Finisce la lettura

                try {
					Thread.sleep(800);
				} catch (InterruptedException e) {
					System.out.println(e);
				}                    																		// Pausa tra una lettura e l'altra
            }

    }

    public void run() {

        leggi();                                    														
    }
}
